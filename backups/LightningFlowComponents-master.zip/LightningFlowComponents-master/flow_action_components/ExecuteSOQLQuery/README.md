See https://unofficialsf.com/a-graphical-soql-query-builder-for-flow/
