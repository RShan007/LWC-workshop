See https://unofficialsf.com/dynamically-launch-autolaunched-flows-from-other-autolaunched-flows/
