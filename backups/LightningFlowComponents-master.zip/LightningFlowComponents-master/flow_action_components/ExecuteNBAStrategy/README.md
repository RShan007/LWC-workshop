See https://unofficialsf.com/execute-an-nba-strategy-and-display-the-results-in-a-custom-recommendation-component/
