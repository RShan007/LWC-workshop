see https://unofficialsf.com/easily-extract-substrings-tap-the-power-of-regex-with-findtext/
