({
    invoke : function(component, event, helper) {
       // Do nothing! Just getting called is enough to commit the transaction.
     }
  })