See https://unofficialsf.com/generate-urls-that-launch-flows-with-generate-flow-link/
