See https://unofficialsf.com/easy-in-filters-in-flow-with-the-filter-query-flow-action/
