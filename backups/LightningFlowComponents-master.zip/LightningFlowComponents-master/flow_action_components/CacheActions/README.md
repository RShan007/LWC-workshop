see https://unofficialsf.com/make-use-of-the-platform-cache-from-flow/
