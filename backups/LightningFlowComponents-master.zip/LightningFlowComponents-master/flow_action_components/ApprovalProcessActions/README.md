See https://unofficialsf.com/use-flow-to-approve-reject-and-cancel-approval-processes/
