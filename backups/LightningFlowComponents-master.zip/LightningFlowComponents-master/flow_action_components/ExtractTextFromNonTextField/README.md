See https://unofficialsf.com/extract-text-from-email-fields-picklist-fields-and-more-with-the-extracttextfromnontextfield-action/
