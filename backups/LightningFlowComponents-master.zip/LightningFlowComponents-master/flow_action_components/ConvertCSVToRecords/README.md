See https://unofficialsf.com/narender-singh-brings-csv-imports-to-flow/
also see: https://unofficialsf.com/enhanced-generate-csv-file-from-record-collection-action/
