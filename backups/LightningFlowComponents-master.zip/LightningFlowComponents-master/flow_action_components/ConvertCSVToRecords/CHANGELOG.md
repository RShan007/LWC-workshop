# Change Log

## [ 10-26-2021 ]

- Add handler for parsing percent fields.
- Add an additional `dateFormat` input parameter. By default the date format is assumed to be either `yyyy-MM-dd` or the user's local date format. If your format is one of `MM/dd/yyyy` or `dd/MM/yyyy`, this can be specified explicitly using the date format parameter. No other date formats are currently supported.
- Added changelog.
