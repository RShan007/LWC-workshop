https://unofficialsf.com/getfieldinformation-get-fields-for-an-object/
