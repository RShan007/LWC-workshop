Documentation and a video demo at https://unofficialsf.com/dynamic-launching-of-screen-flows/
